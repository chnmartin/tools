
/*
 *  Board Setup
 *
 */

#include "C6747.h"
#include "C6747_i2c.h"

Int16 C6747_init( )
{

   sysinit();
   TIMER0_TRC=0x0;
   TIMER1_TRC=0x0;
   return 0;
}

