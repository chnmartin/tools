#include "C6747.h"
/////////////////////////////FPGA///////////////////////////////
///////////////////////0X64000000 ��Ӧ���� XA13--BA1��BA0�ĵ�ַ///////////
///////////////////////��ʵ��Ӳ��ֻ�õ���XA13-BA1�ĵ�ַ�������������и�����һλ�Ĺ�ϵ��//////
#define	  ADC7606_DATA   (*((volatile  Uint16 *)0x64000000))//ADC7606��ַ
#define   DA_CHA         (*((volatile  Uint16 *)0x64001000))//DAC7724��ַ1
#define   DA_CHB         (*((volatile  Uint16 *)0x64001004))//DAC7724��ַ2
#define   DA_CHC         (*((volatile  Uint16 *)0x64001008))//DAC7724��ַ3
#define   DA_CHD         (*((volatile  Uint16 *)0x6400100C))//DAC7724��ַ4

#define	  set_adcclk	GPIO_OUT_DATA45|=0x00000001    //GP4_0 =1
#define   clr_adcclk    GPIO_OUT_DATA45&=0xfffffffe	   //GP4_0 =0
#define	  set_adcrst   	GPIO_OUT_DATA45|=0x00000010    //GP4_4 =1
#define   clr_adcrst    GPIO_OUT_DATA45&=0xffffffef	   //GP4_4 =0
#define	  set_dacldac	GPIO_OUT_DATA23|=0x00000800    //GP2_11 =1
#define   clr_dacldac   GPIO_OUT_DATA23&=0xfffff7ff	   //GP2_11 =0
#define   set_dacrst    GPIO_OUT_DATA23|=0x10000000    //GP3_12 =1
#define   clr_dacrst    GPIO_OUT_DATA23&=0xeffFffff	   //GP3_12 =0

#define   set_led1   	GPIO_OUT_DATA23|=0x00080000    //GP3_3 =1
#define   clr_led1      GPIO_OUT_DATA23&=0xfff7ffff	   //GP3_3 =0
#define   set_led2   	GPIO_OUT_DATA23|=0x00800000    //GP3_7 =1
#define   clr_led2      GPIO_OUT_DATA23&=0xff7fffff	   //GP3_7 =0
#define   set_led3      GPIO_OUT_DATA23|=0x01000000    //GP3_8 =1
#define   clr_led3      GPIO_OUT_DATA23&=0xfeffffff    //GP3_8 =0


/////////////read end////////////////////////////////////////////////////
#define   adc7606_busy  (GPIO_IN_DATA45 & 0x00000004) //GP4_2
#define   KEY1          (GPIO_IN_DATA45 & 0x00000400) //GP4_10
#define   KEY2          (GPIO_IN_DATA45 & 0x00002000) //GP4_13
#define   KEY3          (GPIO_IN_DATA45 & 0x00000002) //GP4_1
#define   KEY4          (GPIO_IN_DATA45 & 0x00000800) //GP4_11

//////////////////////////////////////////////////
Int16 C6747_GPIO_init         (void);
Int16 C6747_GPIO_setDirection (Uint16 number, uchar direction );
Int16 C6747_GPIO_setOutput    (Uint16 number, uchar output );
Int16 C6747_GPIO_getInput     (Uint16 number );
///////////////////////lcd///////////////////////////

///////////////////RS485///////////////////////////////////
void tx_485enable(void);

void rx_485enable(void);

void GetCrcCode(Uint16 len,uchar * str);
extern void  Sci_send (uchar port,uchar * point,Uint16 num);

void DELAY_US (Uint16 t);

void LED3Rev(void);

void ParIni(void);

