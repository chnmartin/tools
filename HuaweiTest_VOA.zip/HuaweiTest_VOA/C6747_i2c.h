/*
 *  Copyright 2008 by Spectrum Digital Incorporated.
 *  All rights reserved. Property of Spectrum Digital Incorporated.
 */

/*
 *  I2C header file
 *
 */

#ifndef I2C_
#define I2C_

#include "C6747.h"


/* ------------------------------------------------------------------------ *
 *  Prototypes                                                              *
 * ------------------------------------------------------------------------ */
Int16 C6747_I2C_init ( );
Int16 C6747_I2C_close( );
Int16 C6747_I2C_write( Uint16 rom_addr, Uint16 len,uchar *data);
Uint16 Writestr(Uint16 addr,Uint16 len,uchar * str);
Int16 C6747_I2C_read( Uint16 rom_addr,  Uint16 len,uchar *data);
void ReadStr(Uint16 addr,Uint16 len,uchar * str);

#endif
