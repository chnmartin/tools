/*
 *  Copyright 2008 by Spectrum Digital Incorporated.
 *  All rights reserved. Property of Spectrum Digital Incorporated.
 */

/*
 *  I2C implementation
 *
 */

#include "C6747_i2c.h"
#define EEPROM_I2C_ADDR 0x50
Int32 i2c_timeout = 0x10000;
////////////////////////////////////////////////////////
//                                                   //
//                                                   //
///////////////////////////////////////////////////////
void waiteeprom(Uint16 delay)
{
  Uint16 i;
  while(delay--)
  {
     for(i=0;i<400;i++)
       ;
  }
}

/* ------------------------------------------------------------------------ *
 *                                                                          *
 *  _I2C_init( )                                                            *
 *                                                                          *
 *      Enable and initalize the I2C module                                 *
 *      The I2C clk is set to run at 20 KHz                                 *
 *                                                                          *
 * ------------------------------------------------------------------------ */
Int16 C6747_I2C_init( )
{
    I2C_ICMDR   = 0;                // Reset I2C
    I2C_ICPSC   = 3;               // Prescale to get 6MHz I2C internal
    I2C_ICCLKL  = 12;               // Config clk LOW for 1.2MHz
    I2C_ICCLKH  = 12;               // Config clk HIGH for 2.4MkHz
    I2C_ICMDR  |= ICMDR_IRS;        // Release I2C from reset
    return 0;
}

/* ------------------------------------------------------------------------ *
 *                                                                          *
 *  _I2C_close( )                                                           *
 *                                                                          *
 * ------------------------------------------------------------------------ */
Int16 C6747_I2C_close( )
{
        I2C_ICMDR = 0;                      // Reset I2C
        return 0;
}

/* ------------------------------------------------------------------------ *
 *                                                                          *
 *  _I2C_reset( )                                                           *
 *                                                                          *
 * ------------------------------------------------------------------------ */
Int16 C6747_I2C_reset( )
{
    C6747_I2C_close( );
    C6747_I2C_init( );
    return 0;
}

/* ------------------------------------------------------------------------ *
 *                                                                          *
 *  _I2C_write( i2c_addr, data, len )                                       *
 *                                                                          *
 *      I2C write in Master mode                                            *
 *                                                                          *
 *      i2c_addr    <- I2C slave address                                    *
 *      data        <- I2C data ptr                                         *
 *      len         <- # of bytes to write                                  *
 *                                                                          *
 * ------------------------------------------------------------------------ */
Int16 C6747_I2C_write( Uint16 rom_addr, Uint16 len,uchar *data)
{
    Int32 i;
    uchar highaddr,lowaddr;
	highaddr=rom_addr>>8;
	lowaddr=rom_addr & 0x00ff;
    I2C_ICSAR = 0x0050; 
	I2C_ICCNT = len+2; 
	I2C_ICDXR=highaddr;
	I2C_ICMDR = 0x6E20; 
	while ( ( I2C_ICSTR & ICSTR_ICXRDY ) == 0 );
    I2C_ICDXR=lowaddr;
    for ( i = 0 ; i < len ; i++ )
    {
      while ( ( I2C_ICSTR & ICSTR_ICXRDY ) == 0 );// Wait for Tx Ready
      I2C_ICDXR = data[i];            // Write 
     }
	 return 0;
}
//////////////////////////////////////
Uint16 Writestr(Uint16 addr,Uint16 len,uchar * str)
{
 Uint16 i=0,j=0;
 j=len/8;
 for(i=0;i<j;i++)
 {
  C6747_I2C_write(addr+i*8,8,str+i*8);
  waiteeprom(2000);//����ȴ�5MS��EEPROM�涨����д���
 }
 return 1;
}
//////////////////////////////////////
/* ------------------------------------------------------------------------ *
 *                                                                          *
 *  _I2C_read( i2c_addr, data, len )                                        *
 *                                                                          *
 *      I2C read in Master mode                                             *
 *                                                                          *
 *      i2c_addr    <- I2C slave address                                    *
 *      data        <- I2C data ptr                                         *
 *      len         <- # of bytes to write                                  *
 *                                                                          *
 *      Returns:    0: PASS                                                 *
 *                 -1: FAIL Timeout                                         *
 *                                                                          *
 * ------------------------------------------------------------------------ */
Int16 C6747_I2C_read( Uint16 rom_addr,  Uint16 len,uchar *data)
{
    Int32  i;
    uchar highaddr,lowaddr;
	highaddr=rom_addr>>8;
	lowaddr=rom_addr & 0x00ff;

                      // Set length
    I2C_ICSAR = 0x0050;               // Set I2C slave address
	while ( ( I2C_ICSTR & ICSTR_ICXRDY ) == 0 );
	I2C_ICCNT = 2;  
    I2C_ICDXR=highaddr;
	I2C_ICMDR = 0x6620; 
    while ( ( I2C_ICSTR & ICSTR_ICXRDY ) == 0 );
    I2C_ICDXR=lowaddr;
    while ( ( I2C_ICSTR & ICSTR_ICXRDY ) == 0 );
	I2C_ICCNT=len;
	I2C_ICSAR = 0x50;
	I2C_ICMDR = 0x2C20;  // recieve mode 
    for ( i = 0 ; i < len ; i++ )
    {
      
        /* Wait for Rx Ready */
        while ( ( I2C_ICSTR & ICSTR_ICRRDY ) == 0 );// Wait for Rx Ready
        data[i] = I2C_ICDRR;            // Read
    }

    return 0;
}

void ReadStr(Uint16 addr,Uint16 len,uchar * str)
{
 Uint16 i=0,j=0;
 j=len/8;
 for(i=0;i<j;i++)
 {
  C6747_I2C_read(addr+i*8,8,str+i*8);  
  waiteeprom(50);
  }

}


