/*
 * Data.h
 *
 *  Created on: 2023��12��12��
 *      Author: XWQ
 */

#ifndef DATA_H_
#define DATA_H_

int Datain(float* Datadbm);

#endif /* DATA_H_ */
